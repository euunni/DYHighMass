#!/usr/bin/env python3

import os, ROOT, sys, pickle, argparse
import uuid
import cmsstyle as CMS
import array
import numpy as np

refLumi = {
    "2016_preVFP": 19.5,
    "2016_postVFP": 16.8,
    "2017": 42.12,
    "2018": 59.45,
    "merged": 137.88
}

histNameList = [
    "h_BTagEff_B",
    "h_BTagEff_C",
    "h_BTagEff_L"
]

MCListName = [
    "DY",
    "GG",
    "TTTo2L2Nu",

    "NNLO_tautau",
    "ST_s",
    "ST_t_AntiTop",
    "ST_t_Top",
    "ST_tW_AntiTop",
    "ST_tW_Top",
    "WW",
    "WZ",
    "ZZ",
]

MergeListName = [
    "NNLO_tautau",
    "ST_s",
    "ST_t_AntiTop",
    "ST_t_Top",
    "ST_tW_AntiTop",
    "ST_tW_Top",
    "WW",
    "WZ",
    "ZZ",
]

eras = [
  "2018",
  "2017",
  "2016_postVFP",
  "2016_preVFP"
]

histNameList = [
  "h_BTagEff_B",
  "h_BTagEff_C",
  "h_BTagEff_L",
]


def plotter(era, xtitle, ytitle, xmin, xmax, ymin, ymax, hist, name):

  CMS.SetExtraText("Private Work")
  CMS.SetEnergy("13")

  fCanvas = CMS.cmsCanvas(
    f"fCanvas_{era}_{name}",
    xmin,
    xmax,
    ymin,
    ymax,
    xtitle,
    ytitle,
    square = True,
    extraSpace = 0.05,
    iPos = 0,
    yTitOffset = 1.25,
    with_z_axis = True
  )

  fCanvas.SetLogy(True)

  fCanvas.cd()  
  CMS.cmsDraw(hist, "colz text e", msize = 1)
    
  fCanvas.SaveAs(f"./BTagEffPlots_eff/plots_MUMU/plots_{era}_{name}.pdf")

def plotter_2DAsymmErrors(era, xtitle, ytitle, xmin, xmax, ymin, ymax, hist, hist_frame, name):

  CMS.SetExtraText("Private Work")
  CMS.SetEnergy("13")

  fCanvas = CMS.cmsCanvas(
    f"fCanvas_{era}_{name}",
    xmin,
    xmax,
    ymin,
    ymax,
    xtitle,
    ytitle,
    square = True,
    extraSpace = 0.05,
    iPos = 0,
    yTitOffset = 1.25,
    with_z_axis = True
  )

  fCanvas.SetLogy(True)

  hist_draw = hist_frame.Clone("hist_draw")
  hist_draw.Reset("ICES")

  rx = array.array("d")
  ry = array.array("d")
  rz = array.array("d")
  elz = array.array("d")
  ehz = array.array("d")

  rx = hist.GetX()
  ry = hist.GetY()
  rz = hist.GetZ()
  elz = hist.GetEZlow()
  ehz = hist.GetEZhigh()

  for i in range(0, len(rx)):
    hist_draw.Fill(rx[i], ry[i], rz[i])

  fCanvas.cd()  
  CMS.cmsDraw(hist_draw, "colz")
  
  fCanvas.cd()
  fLatex = ROOT.TLatex()
  fLatex.SetTextAlign(12)
  fLatex.SetTextSize(0.02);

  for i in range(0, len(rx)):
    # print(f"{rz[i]:1.3f}" + "^{+" + f"{ehz[i]:1.3f}" + "}_{-" + f"{elz[i]:1.3f}" + "}")
    fLatex.DrawLatex(
      rx[i] - 0.3, ry[i], 
      f"{rz[i]:1.3f}" + "^{+" + f"{ehz[i]:1.3f}" + "}_{-" + f"{elz[i]:1.3f}" + "}"
    )

  fCanvas.SaveAs(f"./BTagEffPlots_eff/plots_MUMU/plots_{era}_{name}_TEff.pdf")


def plotter_1D(era, hist, name):

  CMS.SetExtraText("Private Work")
  CMS.SetEnergy("13")

  nPlot = 4
  if "AbsEta" in name:
    nPlot = 2

  fCanvas = CMS.cmsCanvas(
    f"fCanvas_1D_{era}_{name}",
    30,
    1000,
    0,
    1.3,
    "Jet p_{T} [GeV]",
    "Efficiency",
    square = True,
    extraSpace = 0.05,
    iPos = 0,
    yTitOffset = 1.25,
    with_z_axis = True
  )

  fCanvas.SetLogx(True)

  histList = []

  hist_xAxis = hist.GetXaxis()
  hist_yAxis = hist.GetYaxis()

  for iEtaBin in range(1, nPlot + 1):
    histList.append(ROOT.TGraphErrors())

    for iPtBin in range(1, hist_yAxis.GetNbins() + 1):

      if (hist.GetBinContent(iEtaBin, iPtBin) != 0):
        histList[iEtaBin - 1].SetPoint(
          histList[iEtaBin - 1].GetN(),
          hist_yAxis.GetBinCenter(iPtBin),
          hist.GetBinContent(iEtaBin, iPtBin)
        )
        histList[iEtaBin - 1].SetPointError(
          histList[iEtaBin - 1].GetN() - 1,
          hist_yAxis.GetBinWidth(iPtBin) / 2,
          1e-3
        )

  for idx, hist in enumerate(histList):
    print(f"hist {idx} has {hist.GetN()} points, {era}_{name}")
    for i in range(hist.GetN()):
      print(f"  point {i} has x = {hist.GetPointX(i)}, y = {hist.GetPointY(i)}, xerr = {hist.GetErrorX(i)}, yerr = {hist.GetErrorY(i)}")


  fLegend = CMS.cmsLeg(0.65, 0.90 - 0.05 * 3, 0.75, 0.90, textSize=0.03)
  
  if nPlot == 2:
    fLegend.AddEntry(histList[0], "0 < |#eta| < 1.3", "lep")
    fLegend.AddEntry(histList[1], "1.3 < |#eta| < 2.5", "lep")

  if nPlot == 4:
    fLegend.AddEntry(histList[0], "-2.5 < #eta < -1.3", "lep")
    fLegend.AddEntry(histList[1], "-1.3 < #eta < 0", "lep")
    fLegend.AddEntry(histList[2], "0 < #eta < 1.3", "lep")
    fLegend.AddEntry(histList[3], "1.3 < #eta < 2.5", "lep")


  fCanvas.cd()  
  CMS.cmsDraw(histList[0], "pe", mcolor = ROOT.kBlack, lcolor = ROOT.kBlack, lwidth = 2)
  CMS.cmsDraw(histList[1], "pe", mcolor = ROOT.kRed, lcolor = ROOT.kRed, lwidth = 2)
  if nPlot == 4:
    CMS.cmsDraw(histList[2], "pe", mcolor = ROOT.kBlue, lcolor = ROOT.kBlue, lwidth = 2)
    CMS.cmsDraw(histList[3], "pe", mcolor = ROOT.kViolet, lcolor = ROOT.kViolet, lwidth = 2)
  fLegend.Draw()

  fCanvas.SaveAs(f"./BTagEffPlots_eff/plots_MUMU/plots_1D_{era}_{name}.pdf")
    

def SetBinError(hist):
  for i in range(1, hist.GetNbinsX() + 1):
    for j in range(1, hist.GetNbinsY() + 1):
      hist.SetBinError(i, j, np.sqrt(hist.GetBinContent(i, j)))
  
  return hist

def Get2DRatio(num, den):

  hTH1_Passed = ROOT.TH1D("h_passed", "", num.GetNbinsX() * num.GetNbinsY(), 0, num.GetNbinsX() * num.GetNbinsY())
  hTH1_Total = ROOT.TH1D("h_total", "", num.GetNbinsX() * num.GetNbinsY(), 0, num.GetNbinsX() * num.GetNbinsY())
  
  for i in range(1, num.GetNbinsX() + 1):
    for j in range(1, num.GetNbinsY() + 1):
      print ("den: ", den.GetBinContent(i, j), " num: ", num.GetBinContent(i, j))
      if den.GetBinContent(i, j) != 0:
        hTH1_Total.SetBinContent(j + (i - 1) * num.GetNbinsY(), den.GetBinContent(i, j))
        hTH1_Total.SetBinError(j + (i - 1) * num.GetNbinsY(), np.sqrt(den.GetBinContent(i, j)))
      if num.GetBinContent(i, j) != 0:
        hTH1_Passed.SetBinContent(j + (i - 1) * num.GetNbinsY(), num.GetBinContent(i, j))
        hTH1_Passed.SetBinError(j + (i - 1) * num.GetNbinsY(), np.sqrt(num.GetBinContent(i, j)))

      if den.GetBinContent(i, j) < num.GetBinContent(i, j):
        hTH1_Passed.SetBinContent(j + (i - 1) * num.GetNbinsY(), num.GetBinContent(i, j))
        hTH1_Passed.SetBinError(j + (i - 1) * num.GetNbinsY(), np.sqrt(num.GetBinContent(i, j)))
        hTH1_Total.SetBinContent(j + (i - 1) * num.GetNbinsY(), num.GetBinContent(i, j))
        hTH1_Total.SetBinError(j + (i - 1) * num.GetNbinsY(), np.sqrt(num.GetBinContent(i, j)))

  hEff = None
  if ROOT.TEfficiency.CheckConsistency(hTH1_Passed, hTH1_Total):
    hEff = ROOT.TEfficiency(hTH1_Passed, hTH1_Total)
    hEff.SetName("h_eff")
    print("Consistency check passed")
  else:
    print("Consistency check failed")
    print(f"h_pass: {hTH1_Passed.GetNbinsX()}, h_total: {hTH1_Total.GetNbinsX()}")
    return None

  rx = []
  ry = []
  rz = []
  elx = []
  ehx = []
  ely = []
  ehy = []
  elz = []
  ehz = []

  for i in range(1, den.GetNbinsX() + 1):
    for j in range(1, den.GetNbinsY() + 1):

      rx.append(den.GetXaxis().GetBinCenter(i))
      elx.append(den.GetXaxis().GetBinWidth(i) / 2)
      ehx.append(den.GetXaxis().GetBinWidth(i) / 2)
      
      ry.append(den.GetYaxis().GetBinCenter(j))
      ely.append(den.GetYaxis().GetBinWidth(j) / 2)
      ehy.append(den.GetYaxis().GetBinWidth(j) / 2)
      
      rz.append(hEff.GetEfficiency(j + (i - 1) * num.GetNbinsY()))
      elz.append(hEff.GetEfficiencyErrorLow(j + (i - 1) * num.GetNbinsY()))
      ehz.append(hEff.GetEfficiencyErrorUp(j + (i - 1) * num.GetNbinsY()))

  rx = array.array("d", rx)
  ry = array.array("d", ry)
  rz = array.array("d", rz)
  elx = array.array("d", elx)
  ehx = array.array("d", ehx)
  ely = array.array("d", ely)
  ehy = array.array("d", ehy)
  elz = array.array("d", elz)
  ehz = array.array("d", ehz)

  hRatio = ROOT.TGraph2DAsymmErrors(len(rx), rx, ry, rz, elx, ehx, ely, ehy, elz, ehz)

  return hRatio

def GetPtMergedHist(hist, isAbsEta = False):

  ptBins = array.array("d", [30, 70, 140, 300, 1000])
  etaBins = array.array("d", [-2.5, -1.3, 0, 1.3, 2.5])
  if isAbsEta:
    etaBins = array.array("d", [0, 1.3, 2.5])

  returnHist = ROOT.TH2D(f"h_{hist.GetName()}_Merged", "", len(etaBins) - 1, etaBins, len(ptBins) - 1, ptBins)

  for i in range(1, hist.GetNbinsX() + 1):
    for j in range(1, hist.GetNbinsY() + 1):
      returnHist.Fill(hist.GetXaxis().GetBinCenter(i), hist.GetYaxis().GetBinCenter(j), hist.GetBinContent(i, j))
      
  for i in range(1, returnHist.GetNbinsX() + 1):
    for j in range(1, returnHist.GetNbinsY() + 1):
      returnHist.SetBinError(i, j, np.sqrt(returnHist.GetBinContent(i, j)))

  return returnHist


if __name__ == "__main__" :

  ROOT.TH1.AddDirectory(False)

  fInputFile = ROOT.TFile(f"./BTag_MUMU_eff.root", "READ")
  fOutputFile = ROOT.TFile.Open(f"./BTagEff_MUMU_final_v2.root", "RECREATE")


  for era in eras:
    for histName in histNameList:

      CMS.SetLumi(refLumi[era])

      histDen = []
      histNum = []
      histDenAbsEta = []
      histNumAbsEta = []

      histMergePtBinDen = []
      histMergePtBinNum = []
      histMergePtBinDenAbsEta = []
      histMergePtBinNumAbsEta = []

      for mcName in MCListName:

        print(f"{histName}_{mcName}_d")
        
        hist_MC_den = fInputFile.Get(f"{era}/{histName}_{mcName}_d")
        hist_MC_num = fInputFile.Get(f"{era}/{histName}_{mcName}_n")
        hist_MC_r = fInputFile.Get(f"{era}/{histName}_{mcName}_r")

        hist_MC_den.SetName(f"{era}_{histName}_{mcName}_den")
        hist_MC_num.SetName(f"{era}_{histName}_{mcName}_num")
        hist_MC_r.SetName(f"{era}_{histName}_{mcName}_eff")        
        
        hist_MC_den_PtMerged = GetPtMergedHist(hist_MC_den)
        hist_MC_den_PtMerged.SetName(f"{era}_{histName}_{mcName}_den_PtMerged")
        hist_MC_num_PtMerged = GetPtMergedHist(hist_MC_num)
        hist_MC_num_PtMerged.SetName(f"{era}_{histName}_{mcName}_num_PtMerged")

        hist_MC_den_AbsEta = fInputFile.Get(f"{era}/{histName}_{mcName}_d_A")
        hist_MC_num_AbsEta = fInputFile.Get(f"{era}/{histName}_{mcName}_n_A")
        hist_MC_r_AbsEta = fInputFile.Get(f"{era}/{histName}_{mcName}_r_A")    

        hist_MC_den_AbsEta.SetName(f"{era}_{histName}_{mcName}_den_AbsEta")
        hist_MC_num_AbsEta.SetName(f"{era}_{histName}_{mcName}_num_AbsEta")
        hist_MC_r_AbsEta.SetName(f"{era}_{histName}_{mcName}_eff_AbsEta")

        hist_MC_den_AbsEta_PtMerged = GetPtMergedHist(hist_MC_den_AbsEta)
        hist_MC_den_AbsEta_PtMerged.SetName(f"{era}_{histName}_{mcName}_den_AbsEta_PtMerged")
        hist_MC_num_AbsEta_PtMerged = GetPtMergedHist(hist_MC_num_AbsEta)
        hist_MC_num_AbsEta_PtMerged.SetName(f"{era}_{histName}_{mcName}_num_AbsEta_PtMerged")

        if mcName == "DY" or mcName == "GG" or mcName == "TTTo2L2Nu":
          
          hist_MC_r_ratio = Get2DRatio(hist_MC_num, hist_MC_den)
          hist_MC_r_ratio.SetName(f"{era}_{histName}_{mcName}_eff_TEff")
          
          hist_MC_r_AbsEta_ratio = Get2DRatio(hist_MC_num_AbsEta, hist_MC_den_AbsEta)
          hist_MC_r_AbsEta_ratio.SetName(f"{era}_{histName}_{mcName}_eff_AbsEta_TEff")

          hist_MC_r_PtMerged_ratio = Get2DRatio(hist_MC_num_PtMerged, hist_MC_den_PtMerged)
          hist_MC_r_PtMerged_ratio.SetName(f"{era}_{histName}_{mcName}_eff_PtMerged_TEff")

          hist_MC_r_PtMerged_AbsEta_ratio = Get2DRatio(hist_MC_num_AbsEta_PtMerged, hist_MC_den_AbsEta_PtMerged)
          hist_MC_r_PtMerged_AbsEta_ratio.SetName(f"{era}_{histName}_{mcName}_eff_AbsEta_PtMerged_TEff")
          
          fOutputFile.cd()
          hist_MC_r.Write()
          hist_MC_r_AbsEta.Write()
          hist_MC_r_ratio.Write()
          hist_MC_r_AbsEta_ratio.Write()
          hist_MC_r_PtMerged_ratio.Write()
          hist_MC_r_PtMerged_AbsEta_ratio.Write()

        if mcName != "DY" and mcName != "GG" and mcName != "TTTo2L2Nu":
          histDen.append(hist_MC_den)
          histNum.append(hist_MC_num)
          histDenAbsEta.append(hist_MC_den_AbsEta)
          histNumAbsEta.append(hist_MC_num_AbsEta)

        if mcName == "DY" or mcName == "GG" or mcName == "TTTo2L2Nu":
          
          # plotter(era, "#eta", "p_{T}", -2.5, 2.5, 30, 1000, hist_MC_den, f"{histName}_{mcName}_den")
          # plotter(era, "#eta", "p_{T}", -2.5, 2.5, 30, 1000, hist_MC_num, f"{histName}_{mcName}_num")
          plotter(era, "#eta", "p_{T}", -2.5, 2.5, 30, 1000, hist_MC_r, f"{histName}_{mcName}_eff")
          plotter_2DAsymmErrors(era, "#eta", "p_{T}", -2.5, 2.5, 30, 1000, hist_MC_r_ratio, hist_MC_num, f"{histName}_{mcName}_eff_TEff")
          plotter_2DAsymmErrors(era, "#eta", "p_{T}", -2.5, 2.5, 30, 1000, hist_MC_r_PtMerged_ratio, hist_MC_num_PtMerged, f"{histName}_{mcName}_eff_PtMerged_TEff")
  
          # plotter_1D(era, hist_MC_r, f"{histName}_{mcName}_eff")

          # plotter(era, "|#eta|", "p_{T}", 0, 2.5, 30, 1000, hist_MC_den_AbsEta, f"{histName}_{mcName}_den_AbsEta")
          # plotter(era, "|#eta|", "p_{T}", 0, 2.5, 30, 1000, hist_MC_num_AbsEta, f"{histName}_{mcName}_num_AbsEta")
          plotter(era, "|#eta|", "p_{T}", 0, 2.5, 30, 1000, hist_MC_r_AbsEta, f"{histName}_{mcName}_eff_AbsEta")
          plotter_2DAsymmErrors(era, "|#eta|", "p_{T}", 0, 2.5, 30, 1000, hist_MC_r_AbsEta_ratio, hist_MC_num_AbsEta, f"{histName}_{mcName}_eff_AbsEta_TEff")
          plotter_2DAsymmErrors(era, "|#eta|", "p_{T}", 0, 2.5, 30, 1000, hist_MC_r_PtMerged_AbsEta_ratio, hist_MC_num_AbsEta_PtMerged, f"{histName}_{mcName}_eff_AbsEta_PtMerged_TEff")
          # plotter_1D(era, hist_MC_r_AbsEta, f"{histName}_{mcName}_eff_AbsEta")

      histDenMerge = histDen[0].Clone(f"{era}_{histName}_Merged_den")
      for hist in histDen[1:]:
        histDenMerge.Add(hist)
      histDenMerge = SetBinError(histDenMerge)

      histNumMerge = histNum[0].Clone(f"{era}_{histName}_Merged_num")
      for hist in histNum[1:]:
        histNumMerge.Add(hist)
      histNumMerge = SetBinError(histNumMerge)

      histEffMerge = Get2DRatio(histNumMerge, histDenMerge)
      histEffMerge.SetName(f"{era}_{histName}_Merged_eff_TEff")

      histDenAbsEtaMerge = histDenAbsEta[0].Clone(f"{era}_{histName}_Merged_den_AbsEta")
      for hist in histDenAbsEta[1:]:
        histDenAbsEtaMerge.Add(hist)
      histDenAbsEtaMerge = SetBinError(histDenAbsEtaMerge)

      histNumAbsEtaMerge = histNumAbsEta[0].Clone(f"{era}_{histName}_Merged_num_AbsEta")
      for hist in histNumAbsEta[1:]:
        histNumAbsEtaMerge.Add(hist)
      histNumAbsEtaMerge = SetBinError(histNumAbsEtaMerge)

      histEffAbsEtaMerge = Get2DRatio(histNumAbsEtaMerge, histDenAbsEtaMerge)
      histEffAbsEtaMerge.SetName(f"{era}_{histName}_Merged_eff_AbsEta_TEff")

      histDenPtMerged = GetPtMergedHist(histDenMerge)
      histDenPtMerged.SetName(f"{era}_{histName}_Merged_den_PtMerged")

      histNumPtMerged = GetPtMergedHist(histNumMerge)
      histNumPtMerged.SetName(f"{era}_{histName}_Merged_num_PtMerged")

      histEffPtMerged = Get2DRatio(histNumPtMerged, histNumPtMerged)
      histEffPtMerged.SetName(f"{era}_{histName}_Merged_eff_PtMerged_TEff")

      histDenAbsEtaMergePtMerged = GetPtMergedHist(histDenAbsEtaMerge)
      histDenAbsEtaMergePtMerged.SetName(f"{era}_{histName}_Merged_den_AbsEta_PtMerged")

      histNumAbsEtaMergePtMerged = GetPtMergedHist(histNumAbsEtaMerge)
      histNumAbsEtaMergePtMerged.SetName(f"{era}_{histName}_Merged_num_AbsEta_PtMerged")

      histEffAbsEtaPtMerged = Get2DRatio(histNumAbsEtaMergePtMerged, histDenAbsEtaMergePtMerged)
      histEffAbsEtaPtMerged.SetName(f"{era}_{histName}_Merged_eff_AbsEta_PtMerged_TEff")

      plotter_2DAsymmErrors(era, "#eta", "p_{T}", -2.5, 2.5, 30, 1000, histEffMerge, histNumMerge, f"{histName}_Merged_eff_TEff")
      plotter_2DAsymmErrors(era, "#eta", "p_{T}", -2.5, 2.5, 30, 1000, histEffPtMerged, histNumPtMerged, f"{histName}_Merged_eff_PtMerged_TEff")
      plotter_2DAsymmErrors(era, "|#eta|", "p_{T}", 0, 2.5, 30, 1000, histEffAbsEtaMerge, histNumAbsEtaMerge, f"{histName}_Merged_eff_AbsEta_TEff")
      plotter_2DAsymmErrors(era, "|#eta|", "p_{T}", 0, 2.5, 30, 1000, histEffAbsEtaPtMerged, histNumAbsEtaMergePtMerged, f"{histName}_Merged_eff_AbsEta_PtMerged_TEff")

      # plotter(era, "#eta", "p_{T}", -2.5, 2.5, 30, 1000, histDenMerge, f"{histName}_Merged_den")
      # plotter(era, "#eta", "p_{T}", -2.5, 2.5, 30, 1000, histNumMerge, f"{histName}_Merged_num")
      # plotter(era, "#eta", "p_{T}", -2.5, 2.5, 30, 1000, histEffMerge, f"{histName}_Merged_eff")
      # plotter_1D(era, histEffMerge, f"{histName}_Merged_eff")

      # plotter(era, "|#eta|", "p_{T}", 0, 2.5, 30, 1000, histDenAbsEtaMerge, f"{histName}_Merged_den_AbsEta")
      # plotter(era, "|#eta|", "p_{T}", 0, 2.5, 30, 1000, histNumAbsEtaMerge, f"{histName}_Merged_num_AbsEta")
      # plotter(era, "|#eta|", "p_{T}", 0, 2.5, 30, 1000, histEffAbsEtaMerge, f"{histName}_Merged_eff_AbsEta")
      # plotter_1D(era, histEffAbsEtaMerge, f"{histName}_Merged_eff_AbsEta")

      fOutputFile.cd()
      histEffMerge.Write()
      histEffAbsEtaMerge.Write()
      histEffPtMerged.Write()
      histEffAbsEtaPtMerged.Write()

  fOutputFile.Close()
              


