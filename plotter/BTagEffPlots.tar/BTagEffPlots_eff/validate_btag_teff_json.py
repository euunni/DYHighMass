#!/usr/bin/env python3
"""
Validate b-tagging TGraph2DAsymmErrors correctionlib JSON files.

For every graph point, compare correctionlib evaluate({era, case, sample, eta, pt, type}) with:
  - nominal  = z
  - StatUp   = z + ez_high
  - StatDown = z - ez_low
"""

import argparse
import math
from pathlib import Path

from convert_btag_teff_to_json import BASE, CASES, EFF_TYPES, ERAS, SAMPLES


def load_correction(json_path, correction_name):
    import correctionlib

    return correctionlib.CorrectionSet.from_file(str(json_path))[correction_name]


def get_graph(root_file, graph_name):
    graph = root_file.Get(graph_name)
    if not graph:
        raise RuntimeError(f"Missing graph: {graph_name}")
    if not graph.InheritsFrom("TGraph2DAsymmErrors"):
        raise RuntimeError(f"{graph_name} is not a TGraph2DAsymmErrors: {graph.ClassName()}")
    return graph


def values_close(left, right, tolerance):
    return math.isclose(float(left), float(right), rel_tol=tolerance, abs_tol=tolerance)


def validate_graph(correction, graph, era, case, sample, tolerance, max_print):
    mismatches = 0
    checked = 0

    xs = graph.GetX()
    ys = graph.GetY()
    zs = graph.GetZ()
    ez_low = graph.GetEZlow()
    ez_high = graph.GetEZhigh()

    for index in range(graph.GetN()):
        eta = float(xs[index])
        pt = float(ys[index])
        nominal = float(zs[index])
        stat_up = nominal + float(ez_high[index])
        stat_down = nominal - float(ez_low[index])

        expected_values = {
            "nominal": nominal,
            "StatUp": stat_up,
            "StatDown": stat_down,
        }

        for variation, expected in expected_values.items():
            actual = correction.evaluate(era, case, sample, eta, pt, variation)
            checked += 1
            if not values_close(actual, expected, tolerance):
                mismatches += 1
                if mismatches <= max_print:
                    print(
                        "Mismatch: "
                        f"era={era}, case={case}, sample={sample}, "
                        f"point={index}, eta={eta}, pt={pt}, type={variation}, "
                        f"json={actual}, root={expected}"
                    )

    return checked, mismatches


def validate_one_json(root_file, json_path, correction_name, eff_type, tolerance, max_print):
    correction = load_correction(json_path, correction_name)
    total_checked = 0
    total_mismatches = 0

    for era in ERAS:
        for case in CASES:
            for sample in SAMPLES:
                graph_name = f"{era}_h_BTagEff_{case}_{sample}_{eff_type}_TEff"
                graph = get_graph(root_file, graph_name)
                checked, mismatches = validate_graph(
                    correction,
                    graph,
                    era,
                    case,
                    sample,
                    tolerance,
                    max_print,
                )
                total_checked += checked
                total_mismatches += mismatches

    print(f"{json_path}: checked {total_checked} values; mismatches={total_mismatches}")
    return total_checked, total_mismatches


def validate_file(input_path, json_dir, channel, correction_name, tolerance, max_print):
    import ROOT

    root_file = ROOT.TFile.Open(str(input_path), "READ")
    if not root_file or root_file.IsZombie():
        raise RuntimeError(f"Failed to open input ROOT file: {input_path}")

    total_mismatches = 0
    try:
        for eff_type in EFF_TYPES:
            json_path = json_dir / f"BTagEff_{channel}_{eff_type}.json"
            _, mismatches = validate_one_json(
                root_file,
                json_path,
                correction_name,
                eff_type,
                tolerance,
                max_print,
            )
            total_mismatches += mismatches
    finally:
        root_file.Close()

    return total_mismatches


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--mumu-input",
        default=str(BASE / "BTagEff_MUMU_final_v2.root"),
        help="Input MUMU ROOT file",
    )
    parser.add_argument(
        "--ee-input",
        default=str(BASE / "BTagEff_EE_final_v2.root"),
        help="Input EE ROOT file",
    )
    parser.add_argument(
        "--json-dir",
        default=str(BASE),
        help="Directory containing generated JSON files",
    )
    parser.add_argument("--name", default="BTagEff", help="Correction name inside each JSON")
    parser.add_argument("--tolerance", type=float, default=1.0e-12, help="Comparison tolerance")
    parser.add_argument("--max-print", type=int, default=20, help="Maximum mismatches to print per JSON")
    return parser.parse_args()


def main():
    args = parse_args()
    json_dir = Path(args.json_dir)

    total_mismatches = 0
    total_mismatches += validate_file(
        Path(args.mumu_input),
        json_dir,
        "MUMU",
        args.name,
        args.tolerance,
        args.max_print,
    )
    total_mismatches += validate_file(
        Path(args.ee_input),
        json_dir,
        "EE",
        args.name,
        args.tolerance,
        args.max_print,
    )

    if total_mismatches:
        raise SystemExit(f"Validation failed with {total_mismatches} mismatches")

    print("Validation passed")


if __name__ == "__main__":
    main()
