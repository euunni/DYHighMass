#!/usr/bin/env python3
"""
Convert b-tagging TGraph2DAsymmErrors efficiencies to correctionlib schema v2.

Input ROOT objects:
  <era>_h_BTagEff_<case>_<sample>_<type>_TEff

Output JSON correction is evaluated as:
  evaluate({era, case, sample, eta, pt, type})

where type is one of:
  - nominal
  - StatUp
  - StatDown
"""

import argparse
import json
from pathlib import Path


ERAS = ["2016_preVFP", "2016_postVFP", "2017", "2018"]
CASES = ["B", "C", "L"]
SAMPLES = ["DY", "GG", "TTTo2L2Nu", "Merged"]
EFF_TYPES = ["eff", "eff_AbsEta", "eff_PtMerged", "eff_AbsEta_PtMerged"]

BASE = Path(__file__).resolve().parent


def clean_edge(value):
    value = float(value)
    if abs(value) < 1.0e-12:
        return 0.0
    return round(value, 10)


def clean_value(value):
    value = float(value)
    if abs(value) < 1.0e-15:
        return 0.0
    return value


def category_node(input_name, content):
    return {
        "nodetype": "category",
        "input": input_name,
        "content": content,
    }


def variation_node(nominal, stat_up, stat_down):
    return category_node(
        "type",
        [
            {"key": "nominal", "value": clean_value(nominal)},
            {"key": "StatUp", "value": clean_value(stat_up)},
            {"key": "StatDown", "value": clean_value(stat_down)},
        ],
    )


def unique_sorted(values):
    return sorted(set(clean_edge(value) for value in values))


def find_bin_index(edges, low, high):
    low = clean_edge(low)
    high = clean_edge(high)
    for index in range(len(edges) - 1):
        if edges[index] == low and edges[index + 1] == high:
            return index
    raise RuntimeError(f"Could not match bin edges [{low}, {high}] in {edges}")


def graph_points(graph):
    n_points = graph.GetN()
    xs = graph.GetX()
    ys = graph.GetY()
    zs = graph.GetZ()
    ex_low = graph.GetEXlow()
    ex_high = graph.GetEXhigh()
    ey_low = graph.GetEYlow()
    ey_high = graph.GetEYhigh()
    ez_low = graph.GetEZlow()
    ez_high = graph.GetEZhigh()

    points = []
    for index in range(n_points):
        x = float(xs[index])
        y = float(ys[index])
        z = float(zs[index])
        points.append(
            {
                "x_low": clean_edge(x - float(ex_low[index])),
                "x_high": clean_edge(x + float(ex_high[index])),
                "y_low": clean_edge(y - float(ey_low[index])),
                "y_high": clean_edge(y + float(ey_high[index])),
                "x_center": clean_value(x),
                "y_center": clean_value(y),
                "nominal": clean_value(z),
                "StatUp": clean_value(z + float(ez_high[index])),
                "StatDown": clean_value(z - float(ez_low[index])),
            }
        )
    return points


def graph_to_eta_pt_node(graph):
    points = graph_points(graph)
    x_edges = unique_sorted([point["x_low"] for point in points] + [point["x_high"] for point in points])
    y_edges = unique_sorted([point["y_low"] for point in points] + [point["y_high"] for point in points])

    grid = [[None for _ in range(len(y_edges) - 1)] for _ in range(len(x_edges) - 1)]
    for point in points:
        x_index = find_bin_index(x_edges, point["x_low"], point["x_high"])
        y_index = find_bin_index(y_edges, point["y_low"], point["y_high"])
        if grid[x_index][y_index] is not None:
            raise RuntimeError(
                "Duplicate graph point for "
                f"eta=[{point['x_low']}, {point['x_high']}], "
                f"pt=[{point['y_low']}, {point['y_high']}]"
            )
        grid[x_index][y_index] = variation_node(point["nominal"], point["StatUp"], point["StatDown"])

    eta_content = []
    for x_index, pt_nodes in enumerate(grid):
        for y_index, node in enumerate(pt_nodes):
            if node is None:
                raise RuntimeError(
                    "Missing graph point for "
                    f"eta=[{x_edges[x_index]}, {x_edges[x_index + 1]}], "
                    f"pt=[{y_edges[y_index]}, {y_edges[y_index + 1]}]"
                )

        eta_content.append(
            {
                "nodetype": "binning",
                "input": "pt",
                "edges": y_edges,
                "content": pt_nodes,
                "flow": "clamp",
            }
        )

    return {
        "nodetype": "binning",
        "input": "eta",
        "edges": x_edges,
        "content": eta_content,
        "flow": "clamp",
    }


def get_graph(root_file, graph_name):
    graph = root_file.Get(graph_name)
    if not graph:
        raise RuntimeError(f"Missing graph: {graph_name}")
    if not graph.InheritsFrom("TGraph2DAsymmErrors"):
        raise RuntimeError(f"{graph_name} is not a TGraph2DAsymmErrors: {graph.ClassName()}")
    return graph


def build_sample_node(root_file, era, case, sample, eff_type):
    graph_name = f"{era}_h_BTagEff_{case}_{sample}_{eff_type}_TEff"
    return graph_to_eta_pt_node(get_graph(root_file, graph_name))


def build_correction(root_file, correction_name, channel, eff_type):
    era_content = []
    for era in ERAS:
        case_content = []
        for case in CASES:
            sample_content = []
            for sample in SAMPLES:
                sample_content.append(
                    {
                        "key": sample,
                        "value": build_sample_node(root_file, era, case, sample, eff_type),
                    }
                )
            case_content.append({"key": case, "value": category_node("sample", sample_content)})
        era_content.append({"key": era, "value": category_node("case", case_content)})

    eta_description = "abs(eta)" if "AbsEta" in eff_type else "eta"
    return {
        "name": correction_name,
        "description": f"{channel} b-tagging efficiency {eff_type} from TGraph2DAsymmErrors.",
        "version": 1,
        "inputs": [
            {"name": "era", "type": "string", "description": "2016_preVFP, 2016_postVFP, 2017, 2018"},
            {"name": "case", "type": "string", "description": "B, C, L"},
            {"name": "sample", "type": "string", "description": "DY, GG, TTTo2L2Nu, Merged"},
            {"name": "eta", "type": "real", "description": eta_description},
            {"name": "pt", "type": "real", "description": "Jet pt"},
            {"name": "type", "type": "string", "description": "nominal, StatUp, or StatDown"},
        ],
        "output": {
            "name": "efficiency",
            "type": "real",
            "description": "B-tagging efficiency",
        },
        "data": category_node("era", era_content),
    }


def write_payload(output_path, correction, channel, eff_type):
    payload = {
        "schema_version": 2,
        "description": f"{channel} b-tagging efficiency {eff_type} converted from TGraph2DAsymmErrors.",
        "corrections": [correction],
    }
    with open(output_path, "w") as output_file:
        json.dump(payload, output_file, indent=4, allow_nan=True)
        output_file.write("\n")


def convert_file(input_path, output_dir, channel, correction_name):
    import ROOT

    root_file = ROOT.TFile.Open(str(input_path), "READ")
    if not root_file or root_file.IsZombie():
        raise RuntimeError(f"Failed to open input ROOT file: {input_path}")

    output_dir.mkdir(parents=True, exist_ok=True)
    try:
        for eff_type in EFF_TYPES:
            output_path = output_dir / f"BTagEff_{channel}_{eff_type}.json"
            correction = build_correction(root_file, correction_name, channel, eff_type)
            write_payload(output_path, correction, channel, eff_type)
            print(f"Wrote {output_path}")
    finally:
        root_file.Close()


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--mumu-input",
        default=str(BASE / "BTagEff_MUMU_final_v2.root"),
        help="Input MUMU ROOT file",
    )
    parser.add_argument(
        "--ee-input",
        default=str(BASE / "BTagEff_EE_final_v2.root"),
        help="Input EE ROOT file",
    )
    parser.add_argument(
        "--output-dir",
        default=str(BASE),
        help="Directory where JSON files are written",
    )
    parser.add_argument("--name", default="BTagEff", help="Correction name inside each JSON")
    return parser.parse_args()


def main():
    args = parse_args()
    output_dir = Path(args.output_dir)
    convert_file(Path(args.mumu_input), output_dir, "MUMU", args.name)
    convert_file(Path(args.ee_input), output_dir, "EE", args.name)


if __name__ == "__main__":
    main()
